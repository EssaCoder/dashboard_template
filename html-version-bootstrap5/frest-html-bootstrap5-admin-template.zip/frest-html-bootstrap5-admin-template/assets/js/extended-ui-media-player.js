/**
 * Media Player
 */

'use strict';

(function () {
  const videoPlayer = new Plyr('#plyr-video-player');
  const audioPlayer = new Plyr('#plyr-audio-player');
})();
